chrome.action.onClicked.addListener(function(tab) {
  const url = "https://drphe.github.io/BM/vnindex";
 chrome.tabs.create({ url: url });
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "wichart",
    title: "Mở Wichart",
    contexts: ["page", "selection", "link", "image"]
  });
  console.log("Menu Wichart đã được tạo.");
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  // Kiểm tra xem mục menu được nhấp có phải là của chúng ta không
  // (hữu ích khi có nhiều mục menu khác nhau).
  if (info.menuItemId === "wichart") {
    const wichartUrl = "https://wichart.vn";
    
    // Mở một tab mới với URL đã chỉ định.
    chrome.tabs.create({ url: wichartUrl });
  }
});