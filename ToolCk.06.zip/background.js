chrome.action.onClicked.addListener(function(tab) {
  const url = "https://drphe.github.io/BM/vnindex";
 chrome.tabs.create({ url: url });
});