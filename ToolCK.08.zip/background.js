chrome.action.onClicked.addListener(function(tab) {
  const url = "https://drphe.github.io/BM/vnindex";
 chrome.tabs.create({ url: url });
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "wichart",
    title: "Mở Wichart",
    contexts: ["page", "selection", "link", "image"],
    documentUrlPatterns: ["*://*.drphe.github.io/*"]
  });
  console.log("Menu Wichart đã được tạo.");
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  // Kiểm tra xem mục menu được nhấp có phải là của chúng ta không
  // (hữu ích khi có nhiều mục menu khác nhau).
  if (info.menuItemId === "wichart") {
    const wichartUrl = "https://wichart.vn";
    
    // Mở một tab mới với URL đã chỉ định.
    chrome.tabs.create({ url: wichartUrl });
  }
});
// Tạo menu ngữ cảnh khi tiện ích được cài đặt
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "loadVieonAccounts",
    title: "Nạp tài khoản Vieon",
    contexts: ["page"],
    documentUrlPatterns: ["*://*.vieon.vn/*"]
  });
  console.log("Menu Vieon đã được tạo.");
});

// Xử lý khi người dùng nhấp vào menu ngữ cảnh
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "loadVieonAccounts") {
    // Mở popup.html trong một cửa sổ mới
    chrome.windows.create({
      url: 'vieon_helper/popup.html',
      type: 'popup',
      width: 500,
      height: 650
    });
  }
});