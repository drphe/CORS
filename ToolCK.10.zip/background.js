// Truy cập trang web tài chính
chrome.action.onClicked.addListener(function(tab) {
  const url = "https://drphe.github.io/BM/vnindex";
 chrome.tabs.create({ url: url });
});

// Tắt hình mờ trên wichart
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "wichart",
    title: "Mở Wichart",
    contexts: ["page", "selection", "link", "image"],
    documentUrlPatterns: ["*://*.drphe.github.io/*"]
  });
  console.log("Menu Wichart đã được tạo.");
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  // Kiểm tra xem mục menu được nhấp có phải là của chúng ta không
  // (hữu ích khi có nhiều mục menu khác nhau).
  if (info.menuItemId === "wichart") {
    const wichartUrl = "https://wichart.vn";
    
    // Mở một tab mới với URL đã chỉ định.
    chrome.tabs.create({ url: wichartUrl });
  }
});

// Đăng nhập tài khoản Vieon VIP
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "loadVieonAccounts",
    title: "Nạp tài khoản Vieon",
    contexts: ["page"],
    documentUrlPatterns: ["*://*.vieon.vn/*"]
  });
  console.log("Menu Vieon đã được tạo.");
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "loadVieonAccounts") {
    // Mở popup.html trong một cửa sổ mới
    chrome.windows.create({
      url: 'vieon_helper/popup.html',
      type: 'popup',
      width: 500,
      height: 650
    });
  }
});

// Đăng nhập bằng cookie
//chrome.runtime.onInstalled.addListener(() => {
 // chrome.contextMenus.create({
   // id: "loginWithCookie",
   // title: "Đăng nhập bằng cookie",
   // contexts: ["page"],
   // documentUrlPatterns: ["*://*.netflix.com/*"]
  //});
//});
// Lắng nghe sự kiện click vào nút menu context
//chrome.contextMenus.onClicked.addListener((info, tab) => {
 // if (info.menuItemId === "loginWithCookie") {
    // Gửi tin nhắn đến tab hiện tại để thực hiện hành động
  //  chrome.tabs.sendMessage(tab.id, { action: "applyCookies" });
  //}
//});
// Hướng dẫn sử dụng
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: "open-guide",
        title: "Hướng dẫn sử dụng",
        contexts: ["action"] // Hiển thị khi nhấp chuột phải vào biểu tượng extension
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "open-guide") {
        // Mở file hướng dẫn trong một tab mới
        chrome.tabs.create({ url: "hdsd.html" });
    }
});